package logic.exception;

public class UsernameNotFoundException extends Exception{


	private static final long serialVersionUID = 1L;

}
