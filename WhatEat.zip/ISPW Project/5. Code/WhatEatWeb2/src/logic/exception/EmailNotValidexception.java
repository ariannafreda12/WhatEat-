package logic.exception;

public class EmailNotValidexception extends Exception{

	private static final long serialVersionUID = 1L;

}
