package logic.exception;

public class FieldsNotMatchingException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
